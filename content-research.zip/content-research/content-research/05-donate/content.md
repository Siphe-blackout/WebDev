# Donate Page — Content (donate.html)

**Content type:** Original — written for this project.

## Hero
- Headline: "$40 funds a month of tutoring and two new books."
- Line: "Every gift — one-time or recurring — goes directly toward tutoring
  hours, book mailings, and summer camp seats for students who need them
  most."

## Donation form fields
- Frequency: One-time / Monthly
- Suggested amounts: $25, $40 (default), $75, $150 + custom amount field
- Donor details: full name, email, card number, expiry, CVC
- Legal/trust note: "Roots & Wings is a registered 501(c)(3). Your donation
  is tax-deductible. Payments are processed by a secure third-party
  provider — no card data is stored on this site."

*Rationale for suggested amounts:* $25/$40/$75/$150 is a standard ascending
nonprofit donation-ladder pattern, with $40 set as the default/most
prominent option because it matches the "funds a month of tutoring + 2
books" headline claim — donors see the exact benefit their default gift buys.

## "Why it matters" giving tiers
| Amount | Impact |
|---|---|
| $40 | Tutors + books for 1 month |
| $120 | One student's summer camp seat |
| $500 | A full year of book mailings |
| $1,200 | Trains one new volunteer tutor |

*Rationale:* each tier ties back to a real program cost already described
elsewhere on the site (e.g. $120 camp seat is plausible against "180 campers,
3 sites, 4 weeks, free breakfast/lunch" from the Programs page) so the
figures feel grounded rather than arbitrary.

## Corporate sponsorship
- Heading: "Partner with Roots & Wings"
- Copy: "We work with local and regional businesses on sponsorships that fund
  a school, a summer camp site, or a book-mailing route — with recognition on
  our site and annual report."
