# Programs Page — Content (programs.html)

**Content type:** Original — written for this project.

## Intro
- Headline: "Three ways we put books and support into a child's hands."
- Line: "Every program is free to families and built around consistency —
  the same tutor, the same mailbox, the same summer table, week after week."

## Program 01 — Free Tutoring
- Description: "Twice-weekly sessions, one-on-one or in small groups of up to
  three, held in person at partner schools and community centers or virtually
  for families who need flexibility."
- Feature list:
  - Reading level assessment before a student's first session
  - Trained volunteer tutors matched by grade and reading level
  - Progress tracked and shared with parents every six weeks
  - Available in English and Spanish
- Quick stats: 2x sessions/week · 1:3 tutor-to-student ratio · 310 active
  tutors · 45 min/session

*Rationale:* the 1:3 ratio and 45-minute session length are typical of
real-world after-school literacy tutoring models (e.g. small-group pull-out
tutoring), used here for realism rather than copied from a specific program.

## Program 02 — Book Mailings
- Description: "Every enrolled student receives a book chosen for their
  reading level and interests, mailed directly to their home — building a
  personal library over the course of a school year."
- Supporting stat: "Since 2019 we've mailed more than 42,000 books to
  families across Central Ohio." (matches the 2019 launch date set in the
  About page timeline)
- What families receive:
  - 1 new, age-matched book mailed monthly
  - A reading guide with discussion questions
  - Bonus holiday and summer mailings

## Program 03 — Summer Reading Camps
- Description: "A four-week summer camp designed to stop the 'summer slide' —
  the reading loss that happens when school lets out. Mornings mix structured
  literacy activities with hands-on projects, games, and field trips."
- Feature list:
  - Runs four weeks each July, Monday–Friday, 9am–1pm
  - Free breakfast and lunch provided daily
  - Capped at 60 students per site to keep group sizes small
- Quick stats: 4 weeks/summer · 3 sites across Columbus · 180 campers last
  summer · Free for every family

*Rationale:* "summer slide" is a real, commonly cited term in literacy
education research describing reading-skill regression over school breaks —
used here as accurate terminology, not a copied phrase from any one source.

## Closing CTA
"Know a child who could use a tutor? Enrollment is open year-round and always
free."
