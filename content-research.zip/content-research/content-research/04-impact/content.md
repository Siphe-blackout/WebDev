# Impact & Stories Page — Content (impact.html)

**Content type:** Original — written for this project.

## Hero
- Headline: "The numbers, and the kids behind them."
- Line: "Transparency matters to us — and to our donors. Here's how last
  year's support turned into reading gains."

## Headline statistics (2025)
| Stat | Label |
|---|---|
| 1,850+ | Students served in 2025 |
| 42,000+ | Books mailed since 2019 |
| 88% | Improved a full reading level within a school year |
| 180 | Summer camp graduates |

*Consistency check:* all four figures match the numbers used on the homepage
and About/Programs pages (same 1,850 students, 42,000 books, 88% gains, 180
campers) so the site tells one consistent story rather than contradicting
itself between pages.

## Student stories (fictional, illustrative testimonials)
1. **Grade 2 — Amara, tutoring student since 2024**
   > "I used to skip my turn to read out loud. Now I raise my hand first."
2. **Grade 4 — Parent, book mailing program**
   > "The books that come in the mail are the only ones at our house. My
   > daughter waits by the door for them."
3. **Grade 1 — Camp counselor, summer reading camp**
   > "He went from three sight words in June to reading full sentences by the
   > end of camp."

*Note:* these are illustrative quotes written to represent each of the three
programs (tutoring, book mailings, camp) — not real testimonials from real
individuals. First name used once (Amara) for the grade 2 story to vary tone;
others kept role-based/anonymous, consistent with common nonprofit privacy
practice for minors.

## Annual report highlights (2025)
- $1.2M annual operating budget, 78% directed to program delivery (matches
  the $1.2M figure introduced in the About page timeline for 2026)
- 1,850 students served across 14 partner schools
- 310 active volunteer tutors, up from 240 in 2024
- Reading gains outpaced our five-year average by 6 points

## Where funding goes (allocation breakdown)
| Category | % |
|---|---|
| Tutoring & camps | 58% |
| Book mailings | 20% |
| Operations & admin | 22% |

*Rationale:* a 78% program-delivery / 22% operations split mirrors the
commonly cited nonprofit benchmark (charity watchdog organisations such as
Charity Navigator generally regard 65%+ of spend on program delivery as
efficient) — used here as a realistic, defensible figure rather than an
arbitrary one.

## Closing CTA
"Help us write next year's report. Your donation funds tutoring hours,
books, and camp seats."
