# Volunteer Page — Content (volunteer.html)

**Content type:** Original — written for this project.

## Hero
- Headline: "Two hours a week can change a child's relationship with
  reading."
- Line: "No teaching degree required — just patience, reliability, and a
  willingness to sit down and read with a kid. We train every tutor before
  their first session."

## Process (3 steps)
1. **Apply** — "Fill out the form below — it takes about five minutes."
2. **Get Trained** — "Attend a 90-minute orientation and background check, in
   person or online."
3. **Start Tutoring** — "Get matched with a student and begin your first
   session within two weeks."

## Application context copy
"Sessions run Monday–Thursday afternoons and Saturday mornings, in person at
Columbus-area schools or virtually. Most tutors commit to one two-hour block
per week for a semester."

## Requirements
- Age 16+ (minors require guardian consent)
- Comfortable reading aloud and working with children
- Able to commit to at least one semester
- Background check required for in-person roles

*Rationale:* a background-check requirement for any role working directly
with children (in-person tutoring) reflects standard, expected child-safety
practice for youth-facing nonprofits — included for realism and to signal
duty-of-care, even though this is a fictional organisation.

## Application form fields
Name, email, phone, role interest (dropdown: one-on-one tutoring /
small-group tutoring / summer camp counselor / book mailing volunteer /
corporate volunteer group), availability (dropdown), free-text message.
