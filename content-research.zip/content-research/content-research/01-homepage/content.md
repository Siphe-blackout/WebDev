# Homepage — Content (index.html)

**Content type:** Original — written for this project. No external source;
Roots & Wings is a fictional organisation.

## Page title / meta description
- Title: "Roots & Wings Literacy Project — Every Child, Reading"
- Meta description: "Roots & Wings Literacy Project provides free tutoring,
  book mailings, and summer reading camps to close the childhood literacy gap
  for K–5 students in Columbus, Ohio."

## Hero
- Eyebrow: "Columbus, Ohio · Est. nonprofit"
- Headline: "Every child deserves the words to find their way."
- Supporting line: "Roots & Wings gives K–5 students free tutoring, books
  mailed straight to their door, and summer reading camps that keep the gap
  from growing. Reading is the root; confidence is the wing."
- CTAs: "Donate Today", "Become a Tutor"

## Impact statistics (see also 04-impact/content.md for source figures)
| Stat | Label |
|---|---|
| 1,850+ | Students served each year |
| 42,000+ | Books mailed to date |
| 310 | Active volunteer tutors |
| 88% | Reading gains within one school year |

*Rationale:* figures were built to be internally consistent across the whole
site (e.g. 42,000 books ÷ mailed monthly since 2019 ≈ plausible volume for a
mid-sized nonprofit) rather than copied from any real charity's annual report.

## Programs preview (summarised from 03-programs/content.md)
- **Free Tutoring** — "One-on-one and small-group tutoring twice a week, in
  person and online, matched to each child's reading level."
- **Book Mailings** — "Age-matched books mailed monthly to enrolled families,
  building a home library one envelope at a time."
- **Summer Reading Camps** — "Four weeks of hands-on literacy camp that stops
  the 'summer slide' before it starts."

## Testimonial quote
> "My son went from dreading reading time to asking for one more chapter every
> night. His tutor didn't just teach him words — she gave him confidence."
> — Parent, Near East Side family, tutoring program

*Note:* fictional/illustrative testimonial written for this project, not an
actual quote from a real person. Framed generically (no full name, stock
scenario) consistent with common nonprofit testimonial conventions.

## Annual report teaser
"1,850 students, 310 volunteer tutors, and a reading-gain rate that outpaced
our five-year average. See the full breakdown of where every dollar went."

## Closing CTA band
- Headline: "Ready to help close the gap?"
- Line: "Every $40 provides a child with a month of tutoring and two new
  books." (cross-checked against the $40/month tutoring+books figure used on
  the Donate page for consistency)

## Footer copy
- Tagline: "Closing the childhood literacy gap in Columbus, Ohio — one book,
  one tutor, one confident reader at a time."
- Legal line: "© 2026 Roots & Wings Literacy Project. A 501(c)(3) nonprofit
  organisation. Columbus, Ohio"
