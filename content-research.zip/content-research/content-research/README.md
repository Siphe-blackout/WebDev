# Content Research and Sourcing — Roots & Wings Literacy Project

## Approach

Roots & Wings Literacy Project is a **fictional organisation** created for this
assignment (per the brief: "if the storyline is fictional, you would still be
required to present realistic content for the fictional client"). Because the
organisation does not exist, there is no live website or social media account
to draw existing copy from.

Instead, this folder documents:

1. **Original content** written for each page — realistic, plausible copy
   consistent with a real Columbus, Ohio-based childhood literacy nonprofit
   (mission statements, program descriptions, statistics, testimonials, staff
   framing, etc.). All of this is created content, not copied from any real
   entity, and is treated as the "researched" material for the site.
2. **Real, legally-sourced assets** used to support the content — fonts, an
   icon set, and a map provider — logged in `sources-and-references.md` with
   licence details and citations.
3. **Placeholder notes** for photography, since no real organisation exists to
   photograph. `sources-and-references.md` explains the free/Creative Commons
   image sources that would be used in a production build.

## Folder structure

```
content-research/
├── 01-homepage/content.md
├── 02-about/content.md
├── 03-programs/content.md
├── 04-impact/content.md
├── 05-donate/content.md
├── 06-volunteer/content.md
├── 07-contact/content.md
└── sources-and-references.md
```

Each `content.md` file contains the finished copy used on that page of the
site, broken down section by section, matching the HTML structure.

## Referencing style

All external sources (fonts, icons, map embed, statistic-formatting
conventions) are cited in `sources-and-references.md` using a Harvard-style
reference list. Replace with your institution's required style if different.
