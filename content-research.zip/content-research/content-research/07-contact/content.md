# Contact Page — Content (contact.html)

**Content type:** Original — written for this project.

## Hero
- Headline: "We'd love to hear from you."
- Line: "Questions about enrolling a student, volunteering, donating, or
  partnering with Roots & Wings — reach out any time."

## Locations (2 required per brief — "assignment should contain more than 1
location")
1. **Main Office** — 221 Maplewood Ave, Columbus, OH 43215
2. **Near East Side Tutoring Site** — 815 Oakwood St, Columbus, OH 43203

*Rationale for choosing these addresses/streets:* fictional but
geographically plausible Columbus, Ohio street names and ZIP codes, chosen to
sit within real Columbus ZIP code ranges (432xx) without referencing an
actual building or organisation. Two distinct sites were used — a main
administrative office plus a program delivery site — to reflect how a
tutoring-based nonprofit realistically operates (admin hub + neighbourhood
service point), and to satisfy the brief's "more than 1 location" requirement
meaningfully rather than listing two arbitrary addresses.

## Contact details
- Phone: (614) 555-0148 — uses the reserved 555 exchange convention for
  fictional phone numbers (not a working number)
- Email: hello@rootsandwingsliteracy.org

## Map embeds
Both locations use an OpenStreetMap embed (no API key required, free to use —
see `sources-and-references.md`) centred on approximate coordinates for the
stated Columbus addresses.

## Contact form fields
Name, email, topic (dropdown: enrolling a student / volunteering / donating /
corporate sponsorship / media-press / something else), free-text message.
