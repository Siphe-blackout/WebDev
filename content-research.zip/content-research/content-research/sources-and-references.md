# Sources & References

This log covers every **external, non-original** resource referenced by the
site (fonts, icons, map provider) plus notes on how photography would be
sourced in a production build. Written content itself is original (see
per-page files) and is not repeated here.

---

## 1. Typography

| Font | Use | Source | Licence |
|---|---|---|---|
| Sora | Headings / display text | Google Fonts | Open Font License (OFL) — free for commercial and personal use |
| Inter | Body text | Google Fonts | Open Font License (OFL) — free for commercial and personal use |

**Reference:**
Google Fonts (2025) *Sora*. Available at: https://fonts.google.com/specimen/Sora (Accessed: 12 August 2026).
Google Fonts (2025) *Inter*. Available at: https://fonts.google.com/specimen/Inter (Accessed: 12 August 2026).

---

## 2. Icons

All navigation/social/program icons in the design version of the site are
hand-drawn inline SVG (simple line icons: envelope, book, phone, location
pin, social logos) created directly in code for this project — no icon
library or third-party icon pack was imported, so no icon licence applies.

---

## 3. Maps (Contact page)

| Resource | Use | Source | Licence |
|---|---|---|---|
| Embedded map iframe | Location maps for Main Office and Near East Side Tutoring Site | OpenStreetMap | © OpenStreetMap contributors, Open Database License (ODbL) — free to embed with attribution |

**Reference:**
OpenStreetMap contributors (2026) *OpenStreetMap*. Available at: https://www.openstreetmap.org (Accessed: 12 August 2026).

*Attribution note:* OpenStreetMap's ODbL requires attribution when data is
used substantially; the standard embed widget used here includes OSM's own
"© OpenStreetMap contributors" credit automatically within the iframe.

---


## 4. Statistical/benchmark conventions referenced

Two content decisions were informed by real-world nonprofit sector
conventions rather than invented arbitrarily:

1. **"Summer slide"** — a recognised term in literacy education research
   describing reading-skill regression over school breaks.
   Cooper, H. (2003) 'Summer Learning Loss: The Problem and Some Solutions', *ERIC Digest*. Available at: https://eric.ed.gov (Accessed: 12 August 2026).

2. **Program-spend ratio (~78% to programs / 22% operations)** — reflects the
   commonly cited nonprofit efficiency benchmark used by charity evaluators.
   Charity Navigator (2025) *How Do We Rate Charities' Accountability and Transparency?*. Available at: https://www.charitynavigator.org (Accessed: 12 August 2026).

---

## Referencing style

References above follow **Harvard style**. Replace with your institution's
required referencing style (e.g. APA, IEEE) if different — the source list
and citations themselves will not change, only the formatting.
