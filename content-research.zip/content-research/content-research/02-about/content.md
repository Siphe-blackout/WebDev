# About Page — Content (about.html)

**Content type:** Original — written for this project.

## Hero
- Headline: "Founded on one belief: every child can become a strong reader."
- Line: "We're a 501(c)(3) nonprofit based in Columbus, Ohio, working to close
  the childhood literacy gap for K–5 students through tutoring, books, and
  community."

## Mission
"To ensure every child has the foundational reading skills and access to
books needed to thrive academically and beyond."

## Vision
"To become a leading regional model for accessible, high-impact childhood
literacy support that measurably improves reading outcomes in underserved
communities."

*Rationale:* Mission = what we do now / who it serves. Vision = the
longer-term aspirational state. Kept distinct on purpose, per standard
nonprofit mission/vision-writing convention (mission = present tense action,
vision = future aspirational state).

## Organisation history (timeline)
| Year | Milestone | Copy |
|---|---|---|
| 2016 | Founding | "Roots & Wings began as a volunteer-run reading table at one Columbus elementary school, serving 30 students a week." |
| 2019 | Program expansion | "We introduced monthly book mailings to keep reading materials in students' hands between sessions, reaching families across five ZIP codes." |
| 2022 | Formal nonprofit status | "Roots & Wings became an independent nonprofit and launched its first summer reading camp to combat learning loss." |
| 2026 | Current scale | "Today we operate with an annual budget of roughly $1.2 million, funded by individual donors and corporate sponsors, serving students across Central Ohio." |

*Rationale:* a 10-year founding-to-present arc (2016–2026) was chosen to give
the org a believable growth trajectory: single site → multi-program →
independent 501(c)(3) → regional scale, matching how most literacy nonprofits
of this size actually grow.

## Target audience (six groups)
1. **K–5 Students & Families** — "Children in Columbus-area schools who need
   extra reading support, plus the families who enroll them."
2. **Volunteers & Tutors** — "Community members who commit a few hours a week
   to one-on-one and small-group tutoring."
3. **Schools & Educators** — "Local elementary schools that partner with us to
   identify students who would benefit most from support."
4. **Donors & Sponsors** — "Individuals and corporate partners whose funding
   keeps tutoring, book mailings, and camps free for families."
5. **Our Staff Team** — "A small, dedicated staff of program coordinators,
   literacy specialists, and volunteer managers."
6. **The Wider Community** — "Neighbors, local businesses, and civic groups
   who champion literacy across Central Ohio."

*Rationale:* the brief asks for a defined target audience — these six groups
were chosen because each is referenced elsewhere on the site (donors →
Donate page, volunteers → Volunteer page, schools → Programs page), so the
audience list matches the site's actual calls to action rather than being a
generic list.

## Closing CTA
"Want to be part of the story? Tutors, donors, and partners all have a place
at Roots & Wings."
